package dayoff.dao;

/**
 * Student entity. @author MyEclipse Persistence Tools
 */

public class Student implements java.io.Serializable {

	// Fields

	private String studentId;
	private String studentName;
	private String studentSex;
	private String offreason;
	private Integer days;

	// Constructors

	/** default constructor */
	public Student() {
	}

	/** full constructor */
	public Student(String studentId, String studentName, String studentSex,
			String offreason, Integer days) {
		this.studentId = studentId;
		this.studentName = studentName;
		this.studentSex = studentSex;
		this.offreason = offreason;
		this.days = days;
	}

	// Property accessors

	public String getStudentId() {
		return this.studentId;
	}

	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}

	public String getStudentName() {
		return this.studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getStudentSex() {
		return this.studentSex;
	}

	public void setStudentSex(String studentSex) {
		this.studentSex = studentSex;
	}

	public String getOffreason() {
		return this.offreason;
	}

	public void setOffreason(String offreason) {
		this.offreason = offreason;
	}

	public Integer getDays() {
		return this.days;
	}

	public void setDays(Integer days) {
		this.days = days;
	}

}