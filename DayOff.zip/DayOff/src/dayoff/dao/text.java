package dayoff.dao;

public class text {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StudentDAO a = new StudentDAO();
		Student b  = new Student("1312", "�Ǻ�", "m", "aaaa", 2);
		a.save(b);
	}

}
