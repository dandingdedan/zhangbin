package dayoff.dao;

/**
 * Login entity. @author MyEclipse Persistence Tools
 */

public class Login implements java.io.Serializable {

	// Fields

	private String usersname;
	private String passwords;

	// Constructors

	/** default constructor */
	public Login() {
	}

	/** full constructor */
	public Login(String usersname, String passwords) {
		this.usersname = usersname;
		this.passwords = passwords;
	}

	// Property accessors

	public String getUsersname() {
		return this.usersname;
	}

	public void setUsersname(String usersname) {
		this.usersname = usersname;
	}

	public String getPasswords() {
		return this.passwords;
	}

	public void setPasswords(String passwords) {
		this.passwords = passwords;
	}

}