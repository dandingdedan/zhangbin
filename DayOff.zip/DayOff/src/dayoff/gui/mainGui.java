package dayoff.gui;

import dayoff.control.StudentControl;
import dayoff.dao.Student;
import dayoff.dao.StudentDAO;

import java.util.ArrayList;
import java.util.List;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;
import javax.swing.JScrollPane;
import javax.swing.JButton;




import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;

import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTextField;
import javax.swing.JLabel;

import java.awt.event.MouseAdapter;

public class mainGui extends JFrame {
	public  mainGui gui = this;
	private JPanel contentPane;
	private JTable table;
	public static List list;
	private JTextField textFieldID;
	private JTextField textFieldName;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					mainGui frame = new mainGui();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public mainGui() {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 512, 403);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JButton btnNewButton = new JButton("\u589E\u52A0");
		/*btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {
						mainGUI inst = new mainGUI();
						inst.setLocationRelativeTo(null);
						inst.setVisible(true);
					}
				});

			}*/

			
		
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AddStudentGUI Studentgui = new AddStudentGUI(gui);
				Studentgui.setVisible(true);
				//AddStudentGUI add = new AddStudentGUI();
				//add.skip();
				
			}
			
			
		
		});
		btnNewButton.setBounds(145, 259, 71, 23);
		panel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("\u5220\u9664");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				//DefaultTableModel tableModel = (DefaultTableModel) getTableStaff().getModel();
				if(getTable().getSelectedRowCount() == 0)
				{
					JOptionPane.showConfirmDialog(null, "��ѡ��Ҫɾ���ļ�¼!","��ʾ", JOptionPane.CLOSED_OPTION);
				}
				
				
				else if(getTable().getSelectedRowCount() == 1)
				{
					int choice = JOptionPane.showConfirmDialog(null, "ѡ�еļ�¼����ɾ��!","�Ƿ�ɾ��:", JOptionPane.OK_CANCEL_OPTION);
					if(choice == 0)
					{
						int i = getTable().getSelectedRow();		
						Student student = StudentControl.getStudentControl().findById(getTable().getModel().getValueAt(i, 0).toString());
						StudentControl.getStudentControl().delete(student);
						
					}
					InitialTable();
					//System.out.println("4");
				}
				   if(getTable().getSelectedRowCount()>1)
	                {
	                	JOptionPane.showConfirmDialog(null, "һ��ֻ��ɾ��һλѧ������Ϣ","��ʾ:", JOptionPane.CLOSED_OPTION);
						return;
	                }
				
				
			
				
			}
		});
		btnNewButton_1.setBounds(52, 259, 71, 23);
		panel.add(btnNewButton_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 10, 466, 204);
		panel.add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"\u5B66\u53F7", "\u59D3\u540D", "\u6027\u522B", "\u539F\u56E0", "\u5929\u6570"
			}
		));
		scrollPane.setViewportView(table);
		
		JLabel lblNewLabel = new JLabel("\u5BF9\u8BF7\u5047\u5B66\u751F\u8FDB\u884C\u64CD\u4F5C");
		lblNewLabel.setBounds(20, 234, 119, 15);
		panel.add(lblNewLabel);
		
		JButton btnNewButton_2 = new JButton("\u4FEE\u6539");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(getTable().getSelectedRowCount() == 0)
				{
					JOptionPane.showConfirmDialog(null, "��ѡ��Ҫ�޸ĵļ�¼!","��ʾ", JOptionPane.CLOSED_OPTION);
				}
				
				else if(getTable().getSelectedRowCount()>1)
                {
                	JOptionPane.showConfirmDialog(null, "һ��ֻ���޸�һλѧ������Ϣ","��ʾ:", JOptionPane.CLOSED_OPTION);
					return;
                }
				else 
				{ 
					ModifyGui modify= new ModifyGui(gui);
					modify.setVisible(true);
				}			
			}
		});
		btnNewButton_2.setBounds(251, 259, 76, 23);
		panel.add(btnNewButton_2);
		
		JLabel lblNewLabel_1 = new JLabel("\u67E5\u627E\u65B9\u5F0F");
		lblNewLabel_1.setBounds(20, 292, 81, 15);
		panel.add(lblNewLabel_1);
		
		JButton btnNewButton_3 = new JButton("\u6309\u5B66\u53F7");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(!textFieldID.getText().equals(""))
				{
					int i;
					for(i = 0;i<table.getModel().getRowCount();i++)
					{
						if(table.getModel().getValueAt(i, 0).toString().equals(textFieldID.getText()))
						{
							table.setRowSelectionInterval(i, i);
							table.setSelectionBackground(Color.RED);
							break;
						}
					
					}
				if(i == table.getModel().getRowCount())
				{
					JOptionPane.showConfirmDialog(null, "û���ҵ�ƥ���¼!","��ʾ", JOptionPane.CLOSED_OPTION);
				}
								
			    }
				else
				{
					JOptionPane.showConfirmDialog(null, "����������ID!","��ʾ", JOptionPane.CLOSED_OPTION);
				}
				textFieldID.setText("");
				
				
			}
		});
		btnNewButton_3.setBounds(52, 317, 76, 23);
		panel.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("\u6309\u59D3\u540D");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
	        ArrayList list = new ArrayList();
				
				if(!textFieldName.getText().equals(""))
				{
					int i;
					int flag = 0;
					for(i = 0;i<table.getModel().getRowCount();i++)
					{
						if(table.getModel().getValueAt(i, 1).toString().equals(textFieldName.getText()))
						{
							list.add(i);							
							flag=1;
						}					
					}
			   if(flag == 1)
					{
					table.setRowSelectionInterval((Integer)list.get(0),(Integer)list.get(list.size()-1));
					table.setSelectionBackground(Color.RED);
					for(int j = (Integer)list.get(0);j<(Integer)list.get(list.size()-1);j++)
					{
						
						if(!table.getModel().getValueAt(j, 1).toString().equals(textFieldName.getText()))
						{
							table.removeRowSelectionInterval(j, j);
						}
					}
					}
				if(flag == 0)
				{
					JOptionPane.showConfirmDialog(null, "û���ҵ�ƥ���¼!","��ʾ", JOptionPane.CLOSED_OPTION);
				}
			}
				else
				{
					JOptionPane.showConfirmDialog(null, "����������ѧ������!","��ʾ", JOptionPane.CLOSED_OPTION);
				}	
				
				textFieldName.setText("");	
				
				
			}
		});
		btnNewButton_4.setBounds(251, 317, 76, 23);
		panel.add(btnNewButton_4);
		
		textFieldID = new JTextField();
		textFieldID.setBounds(150, 318, 66, 21);
		panel.add(textFieldID);
		textFieldID.setColumns(10);
		
		textFieldName = new JTextField();
		textFieldName.setBounds(368, 318, 66, 21);
		panel.add(textFieldName);
		textFieldName.setColumns(10);
		InitialTable();
	}
	
	public JTable getTable() {
		return table;
	}
	public void InitialTable()
	{
		DefaultTableModel tableModel = (DefaultTableModel) getTable().getModel();
		if(tableModel.getRowCount() != 0)
		{
			tableModel.setRowCount(0);
		}
		list = StudentControl.getStudentControl().findALL();	

		for(int i = 0;i < list.size();i++)
		{
			Student student = (Student)list.get(i);
			
			tableModel.addRow(new Object[] {
				student.getStudentId().toString(),student.getStudentName().toString(),
				student.getStudentSex().toString(),student.getOffreason().toString(),student.getDays().toString()});
		}
	}
		
	public void skip()
   {
	SwingUtilities.invokeLater(new Runnable() {
		public void run() {
			mainGui inst = new mainGui();
			inst.setLocationRelativeTo(null);
			inst.setVisible(true);
		}
	});
    }
}
