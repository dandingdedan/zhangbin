package dayoff.gui;

import java.awt.BorderLayout;
import java.util.List;
import java.util.regex.Matcher;
import java.awt.EventQueue;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;

import dayoff.control.StudentControl;
import dayoff.dao.Student;
import dayoff.dao.StudentDAO;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JComboBox;

public class AddStudentGUI extends JFrame {

	private JPanel contentPane;
	private JTextField textField_ID;
	private JTextField textField_Name;
	private JTextField textField_days;
	private JComboBox<?> comboBox;
	private JComboBox<?> comboBox_1;
	static mainGui localfather;
	final String [] temp = new String[5];
	
	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AddStudentGUI frame = new AddStudentGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	*/


	/**
	 * Create the frame.
	 */
	public AddStudentGUI(mainGui father) {
		localfather = father;
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u5B66\u751F\u5B66\u53F7");
		lblNewLabel.setBounds(41, 46, 54, 15);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("\u5B66\u751F\u59D3\u540D");
		lblNewLabel_1.setBounds(41, 100, 54, 15);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_3 = new JLabel("\u5B66\u751F\u6027\u522B");
		lblNewLabel_3.setBounds(228, 46, 54, 15);
		panel.add(lblNewLabel_3);
		
		JLabel label = new JLabel("\u8BF7\u5047\u539F\u56E0");
		label.setBounds(228, 100, 54, 15);
		panel.add(label);
		
		JLabel lblNewLabel_4 = new JLabel("\u8BF7\u5047\u5929\u6570");
		lblNewLabel_4.setBounds(41, 157, 54, 15);
		panel.add(lblNewLabel_4);
		
		textField_ID = new JTextField();
		textField_ID.setBounds(116, 43, 66, 21);
		panel.add(textField_ID);
		textField_ID.setColumns(10);
		
		textField_Name = new JTextField();
		textField_Name.setBounds(116, 97, 66, 21);
		panel.add(textField_Name);
		textField_Name.setColumns(10);
		
		textField_days = new JTextField();
		textField_days.setBounds(116, 154, 66, 21);
		panel.add(textField_days);
		textField_days.setColumns(10);
		
		JButton btnNewButton = new JButton("\u786E\u5B9A");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				temp[0] = textField_ID.getText();
				temp[1]	= textField_Name.getText();	
				

				if(comboBox.getSelectedItem().toString().equals("��"))
					temp[2]="M";
				else
					temp[2] = "F";
				if(comboBox_1.getSelectedItem().toString().equals("�¼�"))
					temp[3]="thing";
				else
					temp[3] = "ill";
				temp[4] = textField_days.getText();
				String str=textField_days.getText();
				boolean result=str.matches("[0-9]+");
				boolean idUnique = true;
				for(int i = 0;i < localfather.list.size(); i++)
				{
					if(temp[0].equals(((Student)localfather.list.get(i)).getStudentId().toString()))
					{
						idUnique = false;
						break;
					}
				}
				if(temp[0].equals(""))
				{
					JOptionPane.showConfirmDialog(null, "��дѧ��ѧ��","��ʾ", JOptionPane.CLOSED_OPTION);
				}
				else if(textField_ID.getText().length()!=9)
				{
					try
					{
						throw new Exception();
					
					}
					catch(Exception b)
					{
						JOptionPane.showConfirmDialog(null, "ѧ��IDֻ��Ϊ9λ","��ʾ:", JOptionPane.CLOSED_OPTION);
						return;
					}
				}
				else if(!result)
				{
					try
					{
						throw new Exception();
					
					}
					catch(Exception b)
					{
						JOptionPane.showConfirmDialog(null, "������������Ĳ�������","��ʾ:", JOptionPane.CLOSED_OPTION);
						return;
					}
				}
				else if((temp[1].equals(""))||(temp[4].equals("")))
				{
					JOptionPane.showConfirmDialog(null, "ѧ����Ϣ��������","��ʾ", JOptionPane.CLOSED_OPTION);
				}
				else if(textField_Name.getText().length()>20)
				{
					try
					{
						throw new Exception();
					
					}
					catch(Exception b)
					{
						JOptionPane.showConfirmDialog(null, "ѧ���������ܳ���20λ","��ʾ:", JOptionPane.CLOSED_OPTION);
						return;
					}
				}
				
				
				else if (isChinese(textField_Name.getText()))
				{
					
					try
					{
						throw new Exception();
					
					}
					catch(Exception b)
					{
						JOptionPane.showConfirmDialog(null, "ѧ����������Ϊ����","��ʾ:", JOptionPane.CLOSED_OPTION);
						return;
					}
				}
				
				else if(!idUnique)
				{
					JOptionPane.showConfirmDialog(null, "��ѧ���Ѵ��ڣ�","��ʾ", JOptionPane.CLOSED_OPTION);
				}
				
				
				
				/*Student vip =new Student(temp[0], temp[1], temp[2],temp[3],Integer.parseInt(temp[4]));
				
				if(!StudentControl.getStudentControl().save(vip))
				{
					JOptionPane.showConfirmDialog(null, "��Ҫ���ӵ�ѧ���Ѵ���,���������롣","��ʾ:", JOptionPane.CLOSED_OPTION);
					return;
				}
				    
				JOptionPane.showConfirmDialog(null, "���ӳɹ�","��ʾ:", JOptionPane.CLOSED_OPTION);
				localfather.InitialTable();
				dispose();*/
				
				
			
				
				
				
				
                else
				{
                	try{
				
					DefaultTableModel tableModel = (DefaultTableModel) localfather.getTable().getModel();
					tableModel.addRow(new Object[] {temp[0],temp[1],temp[2],temp[3],temp[4]});
					StudentControl.getStudentControl().save(temp[0], temp[1], temp[2],temp[3],Integer.parseInt(temp[4]));
                	}
                	catch(Exception b)
					{
                		localfather.InitialTable();
    					dispose();
                	
					}
					
				 }	
			}
		});
		btnNewButton.setBounds(228, 153, 66, 23);
		panel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("\u8FD4\u56DE");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnNewButton_1.setBounds(307, 153, 66, 23);
		panel.add(btnNewButton_1);
		
		JLabel lblNewLabel_2 = new JLabel("\uFF089\u4F4D\uFF09");
		lblNewLabel_2.setBounds(182, 46, 54, 15);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_5 = new JLabel("\uFF08\u82F1\u6587\uFF09");
		lblNewLabel_5.setBounds(182, 100, 54, 15);
		panel.add(lblNewLabel_5);
		
		comboBox = new JComboBox<Object>();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"��", "Ů"}));
		comboBox.setBounds(307, 43, 55, 21);
		panel.add(comboBox);
		
		comboBox_1 = new JComboBox<Object>();
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"�¼�", "����"}));
		comboBox_1.setBounds(307, 97, 60, 21);
		panel.add(comboBox_1);
	}
	//�жϸ��ַ��Ƿ�Ϊ���� 
	private boolean isChinese(char c) { 
	        Character.UnicodeBlock ub = Character.UnicodeBlock.of(c); 
	        if (ub == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS || ub == Character.UnicodeBlock.CJK_COMPATIBILITY_IDEOGRAPHS 
	                || ub == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS_EXTENSION_A || ub == Character.UnicodeBlock.GENERAL_PUNCTUATION 
	                || ub == Character.UnicodeBlock.CJK_SYMBOLS_AND_PUNCTUATION || ub == Character.UnicodeBlock.HALFWIDTH_AND_FULLWIDTH_FORMS) { 
	            return true; 
	        } 
	        return false; 
	} 

	/*�жϸ��ַ������Ƿ�������*/ 
	private boolean isChinese(String strName) { 
	        char[] ch = strName.toCharArray(); 
	        for (int i = 0; i < ch.length; i++) { 
	            char c = ch[i]; 
	            if (isChinese(c) == true) { 
	                return true; 
	            } 
	        } 
	        return false; 
	} 
	
}



