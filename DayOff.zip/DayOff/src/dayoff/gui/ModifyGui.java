package dayoff.gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JButton;

import dayoff.control.StudentControl;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import dayoff.control.StudentControl;
import dayoff.dao.Student;
import dayoff.dao.StudentDAO;

public class ModifyGui extends JFrame {

	private JPanel contentPane;
	private JTextField textFieldName;
	private JTextField textFieldID;
	private JTextField textFieldDay;
	private JComboBox<?> comboBox_1;
	private JComboBox<?> comboBox_2;
	static mainGui localfather;
	final String [] temp = new String[5];
	/**
	 * Launch the application.
	 */
/*	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ModifyGui frame = new ModifyGui();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ModifyGui(mainGui father) {
		localfather = father;
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		textFieldName = new JTextField();
		textFieldName.setBounds(116, 30, 66, 21);
		panel.add(textFieldName);
		textFieldName.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("\u5B66\u751F\u59D3\u540D");
		lblNewLabel.setBounds(34, 33, 54, 15);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("\u5B66\u751F\u5B66\u53F7");
		lblNewLabel_1.setBounds(34, 104, 54, 15);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("\u8BF7\u5047\u539F\u56E0");
		lblNewLabel_2.setBounds(225, 33, 54, 15);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("\u8BF7\u5047\u5929\u6570");
		lblNewLabel_3.setBounds(225, 104, 54, 15);
		panel.add(lblNewLabel_3);
		
		textFieldID = new JTextField();
		textFieldID.setBounds(116, 101, 66, 21);
		panel.add(textFieldID);
		textFieldID.setColumns(10);
		
		textFieldDay = new JTextField();
		textFieldDay.setBounds(310, 101, 66, 21);
		panel.add(textFieldDay);
		textFieldDay.setColumns(10);
		
		
		
		int rowNum = localfather.getTable().getSelectedRow();	
		
		
		textFieldID.setText(localfather.getTable().getModel().getValueAt(rowNum, 0).toString());
		textFieldName.setText(localfather.getTable().getModel().getValueAt(rowNum, 1).toString());
		textFieldDay.setText(localfather.getTable().getModel().getValueAt(rowNum, 4).toString());
		
		JButton btnNewButton = new JButton("\u4FDD\u5B58");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				temp[0] = textFieldID.getText();
				temp[1]	= textFieldName.getText();	
				temp[4] = textFieldDay.getText();
				if(comboBox_1.getSelectedItem().toString().equals("�¼�"))
					temp[3]="thing";
				else
					temp[3] = "ill";
				if(comboBox_2.getSelectedItem().toString().equals("��"))
					temp[2]="M";
				else
					temp[2] = "F";
				String str=textFieldDay.getText();
				boolean result=str.matches("[0-9]+");
				/*boolean idUnique = true;
				for(int i = 0;i < localfather.list.size(); i++)
				{
					if(temp[0].equals(((Student)localfather.list.get(i)).getStudentId().toString()))
					{
						idUnique = false;
						break;
					}
				}*/
				if(temp[0].equals(""))
				{
					JOptionPane.showConfirmDialog(null, "��дѧ��ѧ��","��ʾ", JOptionPane.CLOSED_OPTION);
				}
				
				else if(!result)
				{
					try
					{
						throw new Exception();
					
					}
					catch(Exception b)
					{
						JOptionPane.showConfirmDialog(null, "������������Ĳ�������","��ʾ:", JOptionPane.CLOSED_OPTION);
						return;
					}
				}
				
				
				
				else if(textFieldID.getText().length()!=9)
				{
					try
					{
						throw new Exception();
					
					}
					catch(Exception b)
					{
						JOptionPane.showConfirmDialog(null, "ѧ��IDֻ��Ϊ9λ","��ʾ:", JOptionPane.CLOSED_OPTION);
						return;
					}
				}
				
				else if((temp[1].equals(""))||(temp[4].equals("")))
				{
					JOptionPane.showConfirmDialog(null, "ѧ����Ϣ��������","��ʾ", JOptionPane.CLOSED_OPTION);
				}
				
				else if(textFieldName.getText().length()>20)
				{
					try
					{
						throw new Exception();
					
					}
					catch(Exception b)
					{
						JOptionPane.showConfirmDialog(null, "ѧ���������ܳ���20λ","��ʾ:", JOptionPane.CLOSED_OPTION);
						return;
					}
				}
				else if (isChinese(textFieldName.getText()))
				{
					
					try
					{
						throw new Exception();
					
					}
					catch(Exception b)
					{
						JOptionPane.showConfirmDialog(null, "ѧ����������Ϊ����","��ʾ:", JOptionPane.CLOSED_OPTION);
						return;
					}
				}
				
				else
				{
					
					DefaultTableModel tableModel = (DefaultTableModel) localfather.getTable().getModel();
					tableModel.addRow(new Object[] {
							temp[0],temp[1],temp[2],temp[3],temp[4]});
					Student student = new Student(temp[0],temp[1],temp[2],temp[3],Integer.parseInt(temp[4]));
					StudentControl.getStudentControl().merge(student);
					dispose();
					localfather.InitialTable();
					
					
				}	
				
				
				
			}
		});
		btnNewButton.setBounds(89, 200, 93, 23);
		panel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("\u8FD4\u56DE");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnNewButton_1.setBounds(283, 200, 93, 23);
		panel.add(btnNewButton_1);
		
		
		comboBox_1 = new JComboBox<Object>();
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"�¼�", "����"}));
	    comboBox_1.setBounds(310, 33, 66, 21);
		panel.add(comboBox_1);
		
		JLabel lblNewLabel_4 = new JLabel("\u6027\u522B");
		lblNewLabel_4.setBounds(128, 158, 54, 15);
		panel.add(lblNewLabel_4);
		
		comboBox_2 = new JComboBox<Object>();
		comboBox_2.setModel(new DefaultComboBoxModel(new String[] {"��", "Ů"}));
		comboBox_2.setBounds(192, 155, 52, 21);
		panel.add(comboBox_2);
	}
	private boolean isChinese(char c) { 
        Character.UnicodeBlock ub = Character.UnicodeBlock.of(c); 
        if (ub == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS || ub == Character.UnicodeBlock.CJK_COMPATIBILITY_IDEOGRAPHS 
                || ub == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS_EXTENSION_A || ub == Character.UnicodeBlock.GENERAL_PUNCTUATION 
                || ub == Character.UnicodeBlock.CJK_SYMBOLS_AND_PUNCTUATION || ub == Character.UnicodeBlock.HALFWIDTH_AND_FULLWIDTH_FORMS) { 
            return true; 
        } 
        return false; 
} 

/*�жϸ��ַ������Ƿ�������*/ 
private boolean isChinese(String strName) { 
        char[] ch = strName.toCharArray(); 
        for (int i = 0; i < ch.length; i++) { 
            char c = ch[i]; 
            if (isChinese(c) == true) { 
                return true; 
            } 
        } 
        return false; 
} 

}
