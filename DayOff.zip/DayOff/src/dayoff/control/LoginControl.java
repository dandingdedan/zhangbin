package dayoff.control;
import java.util.List;
import org.hibernate.Session;
import dayoff.dao.LoginDAO;
import dayoff.factory.HibernateSessionFactory;
import dayoff.dao.Login;

public class LoginControl {

	private static LoginControl control = null; 
	public static LoginControl getLoginControl(){
		if(null==control){
			control = new LoginControl();
		}
		return control;
	}
	

	private LoginDAO LoginDAO = null;
	private Session session = null;
	
	private LoginControl(){
		LoginDAO = new LoginDAO();
		session = HibernateSessionFactory.getSession();
	}
	public Login saveLogin(String username,String password){
		Login Login = new Login(username,password);
		LoginDAO.save(Login);
		session.beginTransaction().commit();
		session.flush();
		return Login;
	}
    
	public Login getLoginByName(String username){
		
	  return (Login)LoginDAO.findByProperty("username",username).get(0);

	}
	public List getLoginALL()
	{
		return LoginDAO.findAll();
	}
	public Boolean delete(Login login) {
		try {

			LoginDAO.delete(login);
			session.beginTransaction().commit();
			session.flush();
			return true;

		} catch (Exception e) {
			return false;
		}
	}
	
	
	
	
}
