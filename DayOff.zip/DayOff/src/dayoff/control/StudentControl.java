package dayoff.control;

import java.util.List;

import org.hibernate.Session;



import dayoff.dao.StudentDAO;
import dayoff.factory.HibernateSessionFactory;
import dayoff.dao.Student;

public class StudentControl {
	private static StudentControl control = null; 
	public static StudentControl getStudentControl(){
		if(null==control){
			control = new StudentControl();
		}
		return control;
	}
	private StudentDAO StudentDAO = null;
	private Session session = null;
	
	private StudentControl(){
		StudentDAO = new StudentDAO();
		session = HibernateSessionFactory.getSession();
	}
	public Student save(String studentId, String studentName, String studentSex,
			String offreason, Integer days){
		Student student = new Student(studentId,studentName, studentSex,offreason, days);
		StudentDAO.save(student);
		session.flush();
		session.beginTransaction().commit();
		return student;
		
	}
    public Student findById(String id){
		
		try {
			Student Student = StudentDAO.findById(id);
			return Student;
		} catch (Exception e) {
			return null;
		}
	}
	public List findByStudentName(String studentName)
	{
		try
		{
			return StudentDAO.findByStudentName(studentName);
		}
		catch(Exception e)
		{
			return null;
		}
	}
	public List findALL()
	{
		return StudentDAO.findAll();
	}
	public Boolean delete(Student student) {
		try {

			StudentDAO.delete(student);
			session.beginTransaction().commit();
			session.flush();
			return true;

		} catch (Exception e) {
			return false;
		}
	}
	
	
	public Boolean merge(Student student) {
		try {

			StudentDAO.merge(student);
			session.beginTransaction().commit();
			session.flush();
			return true;

		} catch (Exception e) {
			return false;
		}
	}
	public boolean save(Student student) {
		// TODO Auto-generated method stub
		try {
		StudentDAO.save(student);
		
		session.beginTransaction().commit();
		session.flush();
		return true;}
		catch (Exception e) {
			return false;
		}
	

	}
	
	
}
