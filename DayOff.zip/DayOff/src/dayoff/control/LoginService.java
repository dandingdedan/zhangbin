package dayoff.control;


import java.util.List;

import javax.swing.JComboBox;

import dayoff.control.LoginControl;
import dayoff.dao.Login;

public class LoginService {
	public static Boolean isUser(String username,String password)
	{
		Login login = LoginControl.getLoginControl().getLoginByName(username);
		if(password.equals(login.getPasswords()))
			return true;
		else
			return false;
			
		
	}
	
	public static void readUser(JComboBox comboBox)
	{
		List logins = LoginControl.getLoginControl().getLoginALL();
		for(int i = 0;i<logins.size();i++)
		{
			comboBox.addItem(((Login)logins.get(i)).getUsersname());
	    }
		
	}
}