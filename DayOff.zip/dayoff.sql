/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50515
Source Host           : localhost:3306
Source Database       : dayoff

Target Server Type    : MYSQL
Target Server Version : 50515
File Encoding         : 65001

Date: 2015-05-28 13:37:48
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for login
-- ----------------------------
DROP TABLE IF EXISTS `login`;
CREATE TABLE `login` (
  `usersname` varchar(20) NOT NULL,
  `passwords` varchar(255) NOT NULL,
  PRIMARY KEY (`usersname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of login
-- ----------------------------
INSERT INTO `login` VALUES ('xdd', '1234');
INSERT INTO `login` VALUES ('zb', '1234');

-- ----------------------------
-- Table structure for student
-- ----------------------------
DROP TABLE IF EXISTS `student`;
CREATE TABLE `student` (
  `studentID` varchar(15) NOT NULL,
  `studentName` varchar(20) NOT NULL,
  `studentSex` char(1) NOT NULL,
  `offreason` varchar(20) NOT NULL,
  `days` int(3) NOT NULL,
  PRIMARY KEY (`studentID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of student
-- ----------------------------
INSERT INTO `student` VALUES ('111111111', 'Bob', 'M', 'thing', '6');
INSERT INTO `student` VALUES ('111111112', 'Jhon', 'M', 'thing', '4');
INSERT INTO `student` VALUES ('111111113', 'Jhon', 'M', 'thing', '4');
INSERT INTO `student` VALUES ('130002413', 'Mik', 'M', 'thing', '3');
INSERT INTO `student` VALUES ('131110432', 'Mar', 'M', 'thing', '2');
